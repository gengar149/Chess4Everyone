﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownMessageDeltaTextContentAnnotation")]
internal partial class UnknownMessageDeltaTextContentAnnotation
{
}