﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownMessageDeltaContent")]
internal partial class UnknownMessageDeltaContent
{
}
