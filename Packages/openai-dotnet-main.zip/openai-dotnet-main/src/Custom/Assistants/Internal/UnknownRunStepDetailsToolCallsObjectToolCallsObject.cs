﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownRunStepDetailsToolCallsObjectToolCallsObject")]
internal partial class UnknownRunStepDetailsToolCallsObjectToolCallsObject
{
}