﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownAssistantToolDefinition")]
internal partial class UnknownAssistantToolDefinition
{
}