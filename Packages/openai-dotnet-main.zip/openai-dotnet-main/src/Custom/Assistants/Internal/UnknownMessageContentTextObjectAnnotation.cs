﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownMessageContentTextObjectAnnotation")]
internal partial class UnknownMessageContentTextObjectAnnotation
{
}