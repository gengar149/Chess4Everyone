﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownRunStepDeltaStepDetailsToolCallsObjectToolCallsObject")]
internal partial class UnknownRunStepDeltaStepDetailsToolCallsObjectToolCallsObject
{
}