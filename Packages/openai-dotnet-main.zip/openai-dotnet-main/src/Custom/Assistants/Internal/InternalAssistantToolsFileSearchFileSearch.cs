namespace OpenAI.Assistants;

[CodeGenModel("AssistantToolsFileSearchFileSearch")]
internal partial class InternalAssistantToolsFileSearchFileSearch
{
    [CodeGenMember("MaxNumResults")]
    internal int? InternalMaxNumResults { get; set; }
}