﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownRunStepDetails")]
internal partial class UnknownRunStepDetails
{
}