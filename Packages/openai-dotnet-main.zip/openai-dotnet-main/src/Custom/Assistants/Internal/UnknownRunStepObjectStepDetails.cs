﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownRunStepObjectStepDetails")]
internal partial class UnknownRunStepObjectStepDetails
{
}