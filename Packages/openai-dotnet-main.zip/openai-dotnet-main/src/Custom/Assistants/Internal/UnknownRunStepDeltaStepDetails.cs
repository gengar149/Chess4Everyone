﻿namespace OpenAI.Assistants;

[CodeGenModel("UnknownRunStepDeltaStepDetails")]
internal partial class UnknownRunStepDeltaStepDetails
{
}