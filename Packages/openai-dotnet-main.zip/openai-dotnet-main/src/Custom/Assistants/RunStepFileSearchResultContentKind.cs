﻿using System.Diagnostics.CodeAnalysis;

namespace OpenAI.Assistants;

// CUSTOM: Renamed.
[Experimental("OPENAI001")]
[CodeGenModel("RunStepDetailsToolCallsFileSearchResultObjectContentType")]
public enum RunStepFileSearchResultContentKind
{
    Text,
}