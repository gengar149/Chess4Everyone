namespace OpenAI.Audio;

/// <summary> The audio format in which to generate the speech. </summary>
[CodeGenModel("CreateSpeechRequestResponseFormat")]
public readonly partial struct GeneratedSpeechFormat
{
}