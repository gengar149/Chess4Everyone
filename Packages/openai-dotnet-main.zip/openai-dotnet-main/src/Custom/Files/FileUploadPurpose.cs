namespace OpenAI.Files;

[CodeGenModel("CreateFileRequestPurpose")]
public readonly partial struct FileUploadPurpose
{
}