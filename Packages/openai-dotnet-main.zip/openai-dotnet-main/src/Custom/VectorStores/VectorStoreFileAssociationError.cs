using System.Diagnostics.CodeAnalysis;

namespace OpenAI.VectorStores;

[Experimental("OPENAI001")]
[CodeGenModel("VectorStoreFileObjectLastError")]
public partial class VectorStoreFileAssociationError
{
}