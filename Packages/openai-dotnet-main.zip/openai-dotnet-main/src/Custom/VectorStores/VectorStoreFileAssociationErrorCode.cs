using System.Diagnostics.CodeAnalysis;

namespace OpenAI.VectorStores;

[Experimental("OPENAI001")]
[CodeGenModel("VectorStoreFileObjectLastErrorCode")]
public readonly partial struct VectorStoreFileAssociationErrorCode
{
}