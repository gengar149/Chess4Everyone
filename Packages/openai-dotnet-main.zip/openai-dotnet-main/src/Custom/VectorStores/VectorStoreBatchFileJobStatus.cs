using System.Diagnostics.CodeAnalysis;

namespace OpenAI.VectorStores;

[Experimental("OPENAI001")]
[CodeGenModel("VectorStoreFileBatchObjectStatus")]
public readonly partial struct VectorStoreBatchFileJobStatus
{
}