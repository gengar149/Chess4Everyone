﻿namespace OpenAI.Chat;

[CodeGenModel("ChatCompletionToolType")]
public enum ChatToolKind
{
    Function,
}
