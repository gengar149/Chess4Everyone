namespace OpenAI.Chat;

[CodeGenModel("UnknownChatCompletionRequestMessage")]
internal partial class InternalUnknownChatMessage : ChatMessage
{

}