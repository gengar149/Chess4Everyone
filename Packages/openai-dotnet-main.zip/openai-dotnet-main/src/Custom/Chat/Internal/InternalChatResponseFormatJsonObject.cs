﻿namespace OpenAI.Chat;

[CodeGenModel("ChatResponseFormatJsonObject")]
internal partial class InternalChatResponseFormatJsonObject
{
}