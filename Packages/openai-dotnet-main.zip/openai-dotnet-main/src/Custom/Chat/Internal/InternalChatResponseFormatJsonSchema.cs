﻿using System.ClientModel.Primitives;
using System.Data;
using System.Text.Json;
using System;

namespace OpenAI.Chat;

[CodeGenModel("ChatResponseFormatJsonSchema")]
internal partial class InternalChatResponseFormatJsonSchema
{
}