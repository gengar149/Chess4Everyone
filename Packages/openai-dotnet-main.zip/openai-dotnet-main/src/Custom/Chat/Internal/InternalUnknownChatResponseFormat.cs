﻿namespace OpenAI.Chat;

[CodeGenModel("UnknownChatResponseFormat")]
internal partial class InternalUnknownChatResponseFormat
{
}