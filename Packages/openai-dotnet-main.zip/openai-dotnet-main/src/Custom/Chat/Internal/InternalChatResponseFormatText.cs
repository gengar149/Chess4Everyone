﻿namespace OpenAI.Chat;

[CodeGenModel("ChatResponseFormatText")]
internal partial class InternalChatResponseFormatText
{
}
