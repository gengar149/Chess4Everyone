namespace OpenAI.Chat;

[CodeGenModel("ChatCompletionMessageToolCallType")]
public enum ChatToolCallKind
{
    Function,
}
