
namespace OpenAI.Models;

[CodeGenModel("DeleteModelResponseObject")]
internal readonly partial struct InternalDeleteModelResponseObject { }

[CodeGenModel("ListModelsResponseObject")]
internal readonly partial struct InternalListModelsResponseObject { }

[CodeGenModel("ModelObject")]
internal readonly partial struct InternalModelObject { }
