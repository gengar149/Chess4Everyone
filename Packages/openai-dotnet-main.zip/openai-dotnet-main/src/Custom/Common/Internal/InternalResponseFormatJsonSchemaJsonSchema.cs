using System;

namespace OpenAI.Internal;

[CodeGenModel("ResponseFormatJsonSchemaJsonSchema")]
internal partial class InternalResponseFormatJsonSchemaJsonSchema
{
    [CodeGenMember("Schema")]
    public BinaryData Schema { get; set; }
}